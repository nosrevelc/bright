<?php
if (!defined('ABSPATH')) {
    exit('restricted access');
}
?>

<?php $vars['self']->show_navigation(); ?>
<div class="postbox" style="padding: 10px;">
    <?php $vars['self']->show_forms(); ?>
</div>
