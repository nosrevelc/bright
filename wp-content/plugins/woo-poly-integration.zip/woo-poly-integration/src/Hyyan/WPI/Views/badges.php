<?php
if (!defined('ABSPATH')) {
    exit('restricted access');
}
?>
<a href="https://wordpress.org/plugins/woo-poly-integration" target="_blank">
    <img src="https://poser.pugx.org/hyyan/woo-poly-integration/v/stable.svg" />
</a>
<a href="https://github.com/hyyan/woo-poly-integration/blob/master/LICENSE" target="_blank">
    <img src="https://poser.pugx.org/hyyan/woo-poly-integration/license.svg"/>
</a>
<a href="http://www.gitchecker.com/hyyan/woo-poly-integration" target="_blank">
    <img src="http://www.repostatus.org/badges/latest/active.svg" />
</a>
