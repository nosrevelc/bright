<?php

// Silence is Golden!
// Plugin code moved to "ajax-login-registration-modal-popup.php"