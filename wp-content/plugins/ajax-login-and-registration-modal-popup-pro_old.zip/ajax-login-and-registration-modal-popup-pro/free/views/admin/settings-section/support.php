<p>
    Check plugin <a href="https://docs.maxim-kaminsky.com/lrm/" target="_blank">documentation</a>.<br/>
    Not found a solution - use <a class="button" target="_blank" href="https://wordpress.org/support/plugin/ajax-login-and-registration-modal-popup">support forum</a>
    <?php if ( lrm_is_pro() ) : ?>
	    or get a <a class="button button-primary" target="_blank" href="https://maxim-kaminsky.com/shop/product/ajax-login-and-registration-modal-popup-pro/">PRO version</a> with Personal email support.
    <?php else: ?>
        or <a class="button button-primary" target="_blank" href="https://maxim-kaminsky.com/shop/submit-ticket/">submit a ticket</a>
    <?php endif; ?>
</p>
