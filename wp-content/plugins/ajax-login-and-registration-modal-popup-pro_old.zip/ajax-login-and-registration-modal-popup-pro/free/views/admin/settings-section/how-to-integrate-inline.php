<p>
    Add shortcode <code>[lrm_form default_tab="login" logged_in_message="You are currently logged in!"]</code><br/>
    You can pass to <strong>default_tab</strong> params: "login", "register" or "lost-password".<br/>
    Param <strong>logged_in_message</strong> will be displayed if used is logged in (html is allowed).<br/>
</p>