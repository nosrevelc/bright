<?php
/* Plugin Name: Theme and plugin translation for Polylang (TTfP)
Description: Polylang - theme and plugin translation for WordPress
Version: 3.2.12
Author: Marcin Kazmierski
License: GPL2
*/

defined('ABSPATH') or die('No script kiddies please!');
include_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'theme-translation-for-polylang.php';